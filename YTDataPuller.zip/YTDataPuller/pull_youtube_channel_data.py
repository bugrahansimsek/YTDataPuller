
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
import pandas as pd
import isodate
import time
from tqdm import tqdm
from datetime import datetime
import os
import re
import sys
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')


def execute_with_retries(request, max_retries=3):
    for attempt in range(max_retries):
        try:
            return request.execute()
        except HttpError as e:
            print(f"❌ API hatası (deneme {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(2)
            else:
                print("⛔ Maksimum deneme sayısına ulaşıldı. İşlem iptal edildi.")
                raise

def extract_channel_id_from_url(youtube, url):
    print("🔹 1. Kanal ID çözülüyor...")
    match_channel = re.search(r"youtube\.com/channel/([a-zA-Z0-9_-]+)", url)
    if match_channel:
        return match_channel.group(1)

    match_handle = re.search(r"youtube\.com/@([a-zA-Z0-9_.-]+)", url)
    if match_handle:
        handle = match_handle.group(1)
        try:
            request = youtube.channels().list(part="id", forHandle=handle)
            response = execute_with_retries(request)
            if response['items']:
                return response['items'][0]['id']
        except Exception as e:
            print(f"❌ Kanal ID alınamadı (handle): {e}")
            return None

    match_custom = re.search(r"youtube\.com/c/([a-zA-Z0-9_.-]+)", url)
    if match_custom:
        custom_name = match_custom.group(1)
        try:
            request = youtube.search().list(part="snippet", q=custom_name, type="channel", maxResults=1)
            response = execute_with_retries(request)
            if response['items']:
                return response['items'][0]['snippet']['channelId']
        except Exception as e:
            print(f"❌ Kanal ID alınamadı (custom URL): {e}")
            return None

    print("⚠️ Geçersiz YouTube kanal URL'si.")
    return None

def get_uploads_playlist_id(youtube, channel_id):
    print("🔹 2. Playlist ID alınıyor...")
    try:
        request = youtube.channels().list(part="contentDetails", id=channel_id)
        response = execute_with_retries(request)
        playlist_id = response['items'][0]['contentDetails']['relatedPlaylists']['uploads']
        print(f"✅ Playlist ID: {playlist_id}")
        return playlist_id
    except Exception as e:
        print(f"❌ Playlist ID alınamadı: {e}")
        return None

def get_all_video_ids(youtube, playlist_id):
    print("🔹 3. Video ID’leri toplanıyor...")
    video_ids = []
    next_page_token = None

    with tqdm(desc="🎥 Video ID'leri", file=sys.stdout) as pbar:
        while True:
            try:
                request = youtube.playlistItems().list(part='contentDetails', playlistId=playlist_id, maxResults=50, pageToken=next_page_token)
                response = execute_with_retries(request)
                video_ids.extend([item['contentDetails']['videoId'] for item in response['items']])
                next_page_token = response.get('nextPageToken')
                pbar.update(len(response['items']))
                if not next_page_token:
                    break
                time.sleep(1)
            except HttpError as e:
                print(f"❌ Video ID çekme hatası: {e}")
                break
    print(f"📌 {len(video_ids)} video bulundu.")
    return video_ids

def get_video_details(youtube, video_ids):
    print("🔹 4. Video detayları çekiliyor...")
    video_data = []
    for i in tqdm(range(0, len(video_ids), 50), desc="🧩 Detaylar", file=sys.stdout):
        batch = video_ids[i:i+50]
        try:
            request = youtube.videos().list(part='snippet,statistics,contentDetails', id=','.join(batch))
            response = execute_with_retries(request)
            for video in response['items']:
                stats = video.get('statistics', {})
                details = video.get('contentDetails', {})
                snippet = video.get('snippet', {})

                published_at = snippet.get('publishedAt', None)
                if published_at:
                    published_at = datetime.strptime(published_at, "%Y-%m-%dT%H:%M:%SZ")
                    formatted_published_at = published_at.strftime("%d/%m/%Y - %H:%M")
                else:
                    formatted_published_at = "Bilinmiyor"

                duration = details.get('duration', "PT0S")
                duration_seconds = isodate.parse_duration(duration).total_seconds()
                video_type = "SHORTS" if duration_seconds <= 60 else "VİDEO"

                category_id = snippet.get('categoryId', "Bilinmiyor")
                category_name = get_video_category(youtube, category_id)

                video_data.append({
                    'Video_ID': video['id'],
                    'Title': snippet.get('title', "Bilinmiyor"),
                    'Published_At': formatted_published_at,
                    'Views': int(stats.get('viewCount', 0)),
                    'Likes': int(stats.get('likeCount', 0)),
                    'Comments': int(stats.get('commentCount', 0)),
                    'Duration': int(duration_seconds),
                    'Video_Type': video_type,
                    'Category': category_name,
                    'Video_URL': f"https://www.youtube.com/watch?v={video['id']}"
                })
            time.sleep(1)
        except HttpError as e:
            print(f"❌ Detay çekme hatası: {e}")
            continue
    return video_data

def get_video_category(youtube, category_id):
    try:
        request = youtube.videoCategories().list(part="snippet", id=category_id)
        response = execute_with_retries(request)
        if 'items' in response and len(response['items']) > 0:
            return response['items'][0]['snippet']['title']
        else:
            return "Bilinmiyor"
    except Exception as e:
        print(f"⚠️ Kategori alınamadı: {e}")
        return "Bilinmiyor"


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("❗ Komut satırı argümanları eksik: <API_KEY> <CHANNEL_URL> <OUTPUT_CSV_PATH>")
        exit(1)

    api_key = sys.argv[1]
    channel_url = sys.argv[2]
    output_path = sys.argv[3]

    print("🚀 Veri çekme işlemi başlatıldı")

    try:
        youtube = build('youtube', 'v3', developerKey=api_key)
        # Geçerli API kontrolü için basit istek
        youtube.channels().list(part="id", id="UC_x5XG1OV2P6uZZ5FSM9Ttw").execute()
    except Exception as e:
        print(f"❌ API anahtarı geçersiz veya bağlantı hatası: {e}")
        exit(1)

    channel_id = extract_channel_id_from_url(youtube, channel_url)
    if not channel_id:
        print("❌ Kanal ID çözülemedi. Lütfen URL’yi kontrol edin.")
        exit(1)

    print(f"✅ Kanal ID: {channel_id}")

    playlist_id = get_uploads_playlist_id(youtube, channel_id)
    if not playlist_id:
        print("❌ Playlist ID bulunamadı.")
        exit(1)

    video_ids = get_all_video_ids(youtube, playlist_id)
    if not video_ids:
        print("❌ Video ID bulunamadı.")
        exit(1)

    data = get_video_details(youtube, video_ids)
    df = pd.DataFrame(data)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False, encoding="utf-8-sig")

    print("✅ CSV başarıyla oluşturuldu.")
    print(f"📁 Dosya: {output_path}")
