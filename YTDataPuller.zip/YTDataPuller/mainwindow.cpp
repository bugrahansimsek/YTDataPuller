#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QProcess>
#include <QFileDialog>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_fetchData_clicked()
{
    QString apiKey = ui->lineEdit_youtubeApi->text().trimmed();
    QString channelUrl = ui->lineEdit_channelURL->text().trimmed();

    // Girdiler kontrol
    if (apiKey.isEmpty() || channelUrl.isEmpty()) {
        QMessageBox::warning(this, "Eksik Bilgi", "Lütfen API anahtarını ve kanal URL'sini giriniz.");
        return;
    }

    // Kayıt yeri seçtir
    QString savePath = QFileDialog::getSaveFileName(this, "CSV dosyasını kaydet", "", "CSV Dosyası (*.csv)");
    if (savePath.isEmpty())
        return;

    // .csv uzantısını zorunlu kıl
    if (!savePath.endsWith(".csv", Qt::CaseInsensitive)) {
        savePath += ".csv";
    }

    // Log başlat
    ui->textEdit_log->append("📡 Veri çekme işlemi başlatıldı...");
    ui->progressBar->setValue(10);

    // Python scripti çalıştır
    QProcess *process = new QProcess(this);
    QString scriptPath = "C:/QT_Code/YoutubeDataCheckApp/pull_youtube_channel_data.py";


    QStringList arguments;
    arguments << apiKey << channelUrl << savePath;

    process->start("python", QStringList() << scriptPath << arguments);

    // Standart çıktıyı oku
    connect(process, &QProcess::readyReadStandardOutput, [=]() {
        QString output = process->readAllStandardOutput().trimmed();
        if (!output.isEmpty())
            ui->textEdit_log->append(output);
        ui->progressBar->setValue(60);
    });

    // Hata çıktısını oku
    connect(process, &QProcess::readyReadStandardError, [=]() {
        QString errorOutput = process->readAllStandardError().trimmed();
        if (!errorOutput.isEmpty())
            ui->textEdit_log->append("🔴 Python Hatası: " + errorOutput);
    });

    // İşlem bittiğinde
    connect(process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            [=](int exitCode, QProcess::ExitStatus status) {
                if (status == QProcess::NormalExit && exitCode == 0) {
                    ui->progressBar->setValue(100);
                    ui->textEdit_log->append("✅ İşlem tamamlandı.");
                } else {
                    ui->progressBar->setValue(0);
                    ui->textEdit_log->append("❌ Hata oluştu, işlem tamamlanamadı.");
                }
                process->deleteLater();
            });
}
